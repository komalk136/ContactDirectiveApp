﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TeleComm_Portal.Models
{
    public class ContactModel
    {
        public int ContactID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Email_Address { get; set; }
        public string Phone_Number { get; set; }
        public string Status { get; set; }
        public string Created_By { get; set; }
        public string Created_When { get; set; }
        public string Touched_By { get; set; }
        public string Touched_When { get; set; }
    }
}