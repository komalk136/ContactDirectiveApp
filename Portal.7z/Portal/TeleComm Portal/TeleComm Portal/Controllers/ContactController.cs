﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using TeleComm_Portal.Models;

namespace TeleComm_Portal.Controllers
{
    public class ContactController : Controller
    {
        private Uri _uri;
        public ContactController()
        {
            _uri = new System.Uri("http://localhost:50946/api/contacttbls");
        }

        // GET: Contact
        public ActionResult Index()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = _uri;

            var task = client.GetAsync(_uri);
            task.Wait();

            var result = task.Result;
            if (result.IsSuccessStatusCode)
            {
                var readTask = result.Content.ReadAsAsync<ContactModel[]>();
                readTask.Wait();

                var logons = readTask.Result;
                return View(logons.ToList());
            }

            return View();
        }
        
        // GET: Contact/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Contact/Create
        [HttpPost]
        public ActionResult Create(ContactModel collection)
        {
            try
            {
                // TODO: Add insert logic here
                HttpClient client = new HttpClient();
                client.BaseAddress = _uri;

                var task = client.PostAsJsonAsync("ContactTbls", collection);
                task.Wait();

                var result = task.Result;
                if (result.IsSuccessStatusCode)
                {
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Contact/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            HttpClient client = new HttpClient();
            client.BaseAddress = _uri;
            var task = client.GetAsync(_uri + "/" + id);
            task.Wait();
            var result = task.Result;
            if (result.IsSuccessStatusCode)
            {
                var responseData = result.Content.ReadAsStringAsync().Result;

                var existingContact = JsonConvert.DeserializeObject<ContactModel>(responseData);
                return View(existingContact);
            }

            return View();
        }

        // POST: Contact/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, ContactModel collection)
        {
            try
            {
                // TODO: Add update logic here
                HttpClient client = new HttpClient();
                client.BaseAddress = _uri;
                var task = client.PutAsJsonAsync(_uri + "/" + id, collection );
                task.Wait();

                var result = task.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Contact/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            HttpClient client = new HttpClient();
            client.BaseAddress = _uri;
            var task = client.GetAsync(_uri + "/" + id);
            task.Wait();
            var result = task.Result;
            if (result.IsSuccessStatusCode)
            {
                var responseData = result.Content.ReadAsStringAsync().Result;

                var existingContact = JsonConvert.DeserializeObject<ContactModel>(responseData);
                return View(existingContact);
            }

            return View();
        }

        // POST: Contact/Delete/5
        [HttpPost]
        public ActionResult Delete(int? id, ContactModel  collection)
        {
            try
            {
                // TODO: Add delete logic here
                HttpClient client = new HttpClient();
                client.BaseAddress = _uri;
                var task = client.DeleteAsync(_uri + "/" + id);
                task.Wait();

                var result = task.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                
                return View();
            }
            catch
            {
                return View();
            }
        }
    }
}
