﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TeleComm_Portal.Controllers;
using TeleComm_Portal.Models;

namespace TeleComm_Portal.Tests
{
    [TestClass]
    public class ContactTest
    {
        /// <summary>
        /// This method used to get Contact Controller
        /// </summary>
        /// <param name="contactRepository">Contact Repository</param>
        /// <returns>Returns employee Controller</returns>
        private static ContactController GetContactController(IContactRepository contactRepository)
        {
            //ContactRepositoryTest contactRepository = new ContactRepositoryTest();
            ContactController contController = new ContactController(contactRepository);
            contController.ControllerContext = new ControllerContext()
            {
                Controller = contController,
                RequestContext = new RequestContext(new MockHttpContext(), new RouteData())
            };

            return contController;
        }

        /// <summary>
        /// This method used to get Contact details
        /// </summary>
        /// <param name="id"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="emailAddress"></param>
        /// <param name="phoneNumber"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        ContactTbl GetContactDetails(int id, string firstName, string lastName, string emailAddress, string phoneNumber, string status)
        {
            return new ContactTbl
            {
                ContactID = id,
                First_Name = firstName,
                Last_Name = lastName,
                Email_Address = emailAddress,
                Phone_Number = phoneNumber,
                Status = status
            };
        }

        /// <summary>
        /// This method used for index view
        /// </summary>
        [TestMethod]
        public void IndexView()
        {
            ContactController controller = GetContactController(new ContactRepository());
            var result = (ViewResult)controller.Index();
            Assert.AreEqual("Index", result.ViewName);
        }

        /// <summary>
        /// This method used to get all contact records
        /// </summary>
        [TestMethod]
        public void GetAllContactsFromRepository()
        {
            // Arrange
            ContactTbl contact1 = GetContactDetails(1, "John", "John", "john@gmail.com", "2722772", "Active");
            ContactTbl contact2 = GetContactDetails(2, "Roy", "Roy", "roy@gmail.com", "555772", "Active");
            IContactRepository contactRepository = new ContactRepository();
            contactRepository.InsertContact(contact1);
            contactRepository.InsertContact(contact2);

            // Act
            var controller = GetContactController(contactRepository);
            var result = (ViewResult)controller.Index();
            var dataModel = (List<ContactTbl>)result.ViewData.Model;

            // Assert
            CollectionAssert.Contains(dataModel.ToList(),contact1);
            CollectionAssert.Contains(dataModel.ToList(), contact2);
        }

        /// <summary>
        /// This methos used to verify view is valid or not
        /// </summary>
        [TestMethod]
        public void ViewIsNotValid()
        {
            ContactController empcontroller = GetContactController(new ContactRepository());
            empcontroller.ModelState.AddModelError("", "View not exits");
            ContactTbl model = GetContactDetails(1, "", "", "", "", "");
            var result = (ViewResult)empcontroller.New(model);
            Assert.AreEqual("New", result.ViewName);
        }

        private class MockHttpContext : HttpContextBase
        {
            private readonly IPrincipal user = new GenericPrincipal(new GenericIdentity("user"), null);

            public override IPrincipal User
            {
                get { return user; }
                set { base.User = value; }
            }
        }
    }
}
