﻿using System.Collections.Generic;
using TeleComm_Portal.Models;

namespace TeleComm_Portal.Tests
{
    public class ContactRepositoryTest : IContactRepository
    {
        private readonly List<ContactTbl> _data = new List<ContactTbl>();

        public IEnumerable<ContactTbl> GetAllContacts() => _data;

        public ContactTbl GetContactById(int? id) => _data.Find(m => m.ContactID == id);

        public void InsertContact(ContactTbl obj) => _data.Add(obj);

        public void UpdateContact(ContactTbl obj) => _data.Find(m => m.ContactID == obj.ContactID);

        public void DeleteContact(int? id)
        {
            var existingContact = _data.Find(m => m.ContactID == id);
            _data.Remove(existingContact);
        }
    }
}