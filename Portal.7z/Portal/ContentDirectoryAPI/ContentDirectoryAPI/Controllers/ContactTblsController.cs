﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ContentDirectoryAPI.Models;

namespace ContentDirectoryAPI.Controllers
{
    public class ContactTblsController : ApiController
    {
        private TeleCommPortalEntities db = new TeleCommPortalEntities();

        // GET: api/ContactTbls
        public IQueryable<ContactTbl> GetContactTbls()
        {
            return db.ContactTbls;
        }

        // GET: api/ContactTbls/5
        [ResponseType(typeof(ContactTbl))]
        public IHttpActionResult GetContactTbl(int id)
        {
            ContactTbl contactTbl = db.ContactTbls.Find(id);
            if (contactTbl == null)
            {
                return NotFound();
            }

            return Ok(contactTbl);
        }

        // PUT: api/ContactTbls/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutContactTbl(int id, [FromBody]ContactTbl contactTbl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != contactTbl.ContactID)
            {
                return BadRequest();
            }

            db.Entry(contactTbl).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactTblExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ContactTbls
        [ResponseType(typeof(ContactTbl))]
        public IHttpActionResult PostContactTbl(ContactTbl contactTbl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ContactTbls.Add(contactTbl);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = contactTbl.ContactID }, contactTbl);
        }

        // DELETE: api/ContactTbls/5
        [ResponseType(typeof(ContactTbl))]
        public IHttpActionResult DeleteContactTbl(int id)
        {
            ContactTbl contactTbl = db.ContactTbls.Find(id);
            if (contactTbl == null)
            {
                return NotFound();
            }

            db.ContactTbls.Remove(contactTbl);
            db.SaveChanges();

            return Ok(contactTbl);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ContactTblExists(int id)
        {
            return db.ContactTbls.Count(e => e.ContactID == id) > 0;
        }
    }
}