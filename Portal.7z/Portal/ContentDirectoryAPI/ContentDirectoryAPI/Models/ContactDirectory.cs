﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Web;

namespace ContentDirectoryAPI.Models
{
    public class ContactDirectory : IContactDirectory
    {
        /// <summary>
        /// Contact DBSet Entity 
        /// </summary>
        private TeleCommPortalEntities db = null;

        /// <summary>
        /// <see cref="ContactDirectory"/> Contact Class
        /// </summary>
        public ContactDirectory()
        {
            this.db = new TeleCommPortalEntities();
        }

        /// <summary>
        /// <see cref="ContactDirectory"/> Contact Class
        /// </summary>
        /// <param name="db">Contact DBSet Entity</param>
        public ContactDirectory(TeleCommPortalEntities db)
        {
            this.db = db;
        }

        /// <summary>
        /// Gets all contacts
        /// </summary>
        /// <returns> Returns all contacts</returns>
        public IEnumerable<ContactTbl> GetAllContacts()
        {
            //HttpClient client = new HttpClient();

            //client.BaseAddress = new System.Uri("http://localhost:56418/api/Login");

            //var task = client.GetAsync("Login");
            //task.Wait();

            //var result = task.Result;
            //if (result.IsSuccessStatusCode)
            //{
            //    var readTask = result.Content.ReadAsAsync<UserModel[]>();
            //    readTask.Wait();

            //    var logons = readTask.Result;
            //}

            return this.db.ContactTbls.ToList();
        }

        /// <summary>
        /// Gets single contact record 
        /// </summary>             
        /// <param name="id">Contact ID</param>
        /// <returns>Returns the specified Contact record</returns>
        public ContactTbl GetContactById(int? id)
        {
            return this.db.ContactTbls.Find(id);
        }

        /// <summary>
        /// Accepts contact objects and adds it to Contact DBSet
        /// </summary>
        /// <param name="obj">Contact Object</param>
        public void InsertContact(ContactTbl obj)
        {
            this.AddTimeStampDetails(ref obj);
            this.db.ContactTbls.Add(obj);
            SaveContact();
        }

        /// <summary>
        /// Accepts contact objects and marks it as modified Contact in the DBSet
        /// </summary>
        /// <param name="obj">Contact Object</param>
        public void UpdateContact(ContactTbl obj)
        {
            this.AddTimeStampDetails(ref obj);
            this.db.Entry(obj).State = EntityState.Modified;
            SaveContact();
        }

        /// <summary>
        /// Accepts contactID and removes it from Contact DBSet
        /// </summary>
        /// <param name="id">Contact ID</param>
        public void DeleteContact(int? id)
        {
            ContactTbl existingContact = this.db.ContactTbls.Find(id);
            if (existingContact != null)
            {
                this.db.ContactTbls.Remove(existingContact);
                this.AddTimeStampDetails(ref existingContact);
                SaveContact();
            }
        }

        /// <summary>
        /// SaveContact changes into db
        /// </summary>
        public void SaveContact()
        {
            this.db.SaveChanges();
        }

        /// <summary>
        /// Add timestamp to the modifying contact object
        /// </summary>
        /// <param name="obj">Contact Object</param>
        private void AddTimeStampDetails(ref ContactTbl obj)
        {
            obj.Touched_When = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            obj.Created_When = DateTime.Now.ToString(CultureInfo.InvariantCulture);
        }
    }
}