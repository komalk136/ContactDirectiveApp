﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContentDirectoryAPI.Models
{
    interface IContactDirectory
    {
        /// <summary>
        /// Gets all contacts
        /// </summary>
        /// <returns> Returns all contacts</returns>
        IEnumerable<ContactTbl> GetAllContacts();

        /// <summary>
        /// Gets single contact record 
        /// </summary>             
        /// <param name="id">Contact ID</param>
        /// <returns>Returns the specified Contact record</returns>
        ContactTbl GetContactById(int? id);

        /// <summary>
        /// Accepts contact objects and adds it to Contact DBSet
        /// </summary>
        /// <param name="obj">Contact Object</param>
        void InsertContact(ContactTbl obj);

        /// <summary>
        /// Accepts contact objects and marks it as modified Contact in the DBSet
        /// </summary>
        /// <param name="obj">Contact Object</param>
        void UpdateContact(ContactTbl obj);

        /// <summary>
        /// Accepts contactID and removes it from Contact DBSet
        /// </summary>
        /// <param name="id">Contact ID</param>
        void DeleteContact(int? id);
    }
}
